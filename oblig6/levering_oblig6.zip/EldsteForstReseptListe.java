/**
* Klasse for EldsteForstReseptListe
* 
* 
* @author mariusch
* @author ingersda
* @version 16.03.15
*/

class EldsteForstReseptListe extends EnkelReseptListe {


}